SARYVEXA Customer Website — Final Customer Build

Files:
- index.html — complete customer-facing website + customer dashboard UI
- app.js — Supabase client initialization helper
- config.js — existing SARYVEXA Supabase URL + public/publishable key

Important:
- This is CUSTOMER ONLY. No admin controls/menu are included.
- Existing Supabase tables/functions are used; no schema SQL is included and nothing should be run in Supabase.
- Existing Login ID RPC is preserved: get_login_email(p_user_id).
- Existing orders use pending / awaiting_payment until the final payment gateway phase.
- Live Instagram/Facebook/YouTube metrics and direct publishing/ads require official APIs and server-side integration; this build does not fabricate those results.
- Post editor, video preview workflow, content planner and promotion brief are included now.

Deployment:
Upload the three files to the root of the Saryvexa-customer GitHub repository used by Render Static Site.

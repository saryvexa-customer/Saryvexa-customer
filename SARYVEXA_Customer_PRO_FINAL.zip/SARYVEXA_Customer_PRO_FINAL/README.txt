SARYVEXA Customer Website — Professional Final Build

Included:
- Premium responsive SARYVEXA customer landing page
- Social-media visual hero and 5 visual slider cards
- Professional customer dashboard with social-media banner
- Dashboard top Search anything... field with direct section navigation
- Customer login via existing get_login_email(p_user_id) RPC
- Create account and password reset
- Social Accounts / target profile save
- Live enabled package loading from existing Supabase packages table
- Order creation using existing orders table; payment remains pending
- Orders and campaigns dashboard
- Post Creator UI
- Video Tools UI
- Content Planner UI
- Ads / Promotion planning UI
- Analytics UI
- Profile, Support, Settings
- Customer-only site; no admin controls

IMPORTANT:
- Do not run any SQL from this ZIP.
- Do not replace/recreate the existing Supabase schema.
- Existing Supabase URL and publishable key are preserved in config.js.
- Existing get_login_email RPC is preserved and called with p_user_id.
- Real payment charging is NOT enabled. Gateway integration can be added later with server-side verification.
- Live social metrics/direct publishing/real ad execution require approved official platform APIs/provider integrations.

Upload:
For the GitHub customer repo, replace the existing index.html, app.js and config.js with these files and upload the assets folder too. Keep the repository structure intact.
